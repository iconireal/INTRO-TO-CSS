document.addEventListener('DOMContentLoaded', () => {
    
    // --- 1. Basic Form Submission Handler (Prevent Default) ---
    // This is crucial. Without a backend, we stop the form from refreshing the page.
    
    const postForm = document.getElementById('propertyPostForm');
    if (postForm) {
        postForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // In a real application, you would use fetch() here to send data to the Django/Node.js backend.
            console.log("Form submitted. Data prepared for backend transmission.");
            
            // Display a success message for the user
            alert("Listing data prepared! Needs a backend server to complete the post.");
            postForm.reset(); // Clear the form after 'submission'
            document.getElementById('media-preview').innerHTML = ''; // Clear previews
        });
    }

    const signInForm = document.getElementById('signInForm');
    if (signInForm) {
        signInForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // In a real app, this sends credentials to the server for authentication.
            console.log("Sign In attempt detected. Needs a backend server for verification.");
            alert("Sign In successful (Demo Mode)! Redirecting...");
            window.location.href = 'index.html'; // Simulate successful login and redirect
        });
    }

    // --- 2. Live Media Preview for Post Listing Page ---
    
    const mediaInput = document.getElementById('media');
    const mediaPreview = document.getElementById('media-preview');
    
    if (mediaInput && mediaPreview) {
        mediaInput.addEventListener('change', function() {
            mediaPreview.innerHTML = ''; // Clear old previews
            
            // Check if files were actually selected
            if (this.files.length === 0) return;

            Array.from(this.files).forEach(file => {
                const reader = new FileReader();
                
                reader.onload = (e) => {
                    const previewItem = document.createElement('div');
                    previewItem.classList.add('preview-item');

                    // Create image or video preview
                    if (file.type.startsWith('image/')) {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.alt = file.name;
                        previewItem.appendChild(img);
                    } else if (file.type.startsWith('video/')) {
                        // For videos, display a simple label (full video preview is complex)
                        const label = document.createElement('p');
                        label.textContent = `Video selected: ${file.name}`;
                        previewItem.appendChild(label);
                    }
                    mediaPreview.appendChild(previewItem);
                };
                
                reader.readAsDataURL(file);
            });
        });
    }
    
    // --- 3. Example function to load property cards (JS dynamic rendering) ---
    
    function loadListings() {
        const grid = document.getElementById('listingGrid');
        if (!grid) return;

        // In a real app, this data would come from a fetch('/api/listings/') call
        const demoListings = [
            { id: 1, title: 'Sunny Apartment in Badagry', price: '₦1,500,000', beds: 3, type: 'Rent', img: 'placeholder1.jpg' },
            { id: 2, title: 'Luxury Duplex, Ikoyi', price: '₦120,000,000', beds: 5, type: 'Sale', img: 'placeholder2.jpg' },
            { id: 3, title: 'Studio Flat Request', price: '₦500,000 Budget', beds: 1, type: 'Request', img: 'placeholder3.jpg' }
        ];

        demoListings.forEach(listing => {
            const cardHTML = `
                <a href="property_detail.html?id=${listing.id}" class="listing-card">
                    <img src="https://via.placeholder.com/350x200?text=Property+Image" alt="${listing.title}">
                    <div class="card-info">
                        <h4>${listing.title}</h4>
                        <p class="price">${listing.price}</p>
                        <p>${listing.beds} Beds · ${listing.type}</p>
                    </div>
                </a>
            `;
            grid.innerHTML += cardHTML;
        });
    }
    
    loadListings();

});
